

function setlink (text) {
    document.getElementById("link").innerText=text;
}